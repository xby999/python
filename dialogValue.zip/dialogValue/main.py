# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import sys
import threading

from PyQt5 import QtCore, QtGui, QtWidgets

import dialog
import main_widget


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}11111222222223333333333344444444')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    widget = QtWidgets.QWidget()
    ui = main_widget.Ui_Form()
    ui.setupUi(widget)
    widget.show()

    # dia = QtWidgets.QDialog()
    # ui = dialog.Ui_Dialog()
    # ui.setupUi(dia)
    # dia.show()
    # sys.exit(app.exec())

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
